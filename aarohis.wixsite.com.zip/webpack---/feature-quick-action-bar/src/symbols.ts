export const name = 'quickActionBar' as const
export const DynamicActionsApiSymbol = Symbol('DynamicActionsApi')
export const DynamicActionsConfigSymbol = Symbol('DynamicActionsConfig')
