import type { ContainerModuleLoader } from '@wix/thunderbolt-ioc'
import { WixCodeSdkHandlersProviderSym, LifeCycle } from '@wix/thunderbolt-symbols'
import { ConsentPolicySymbol } from './symbols'
import { ConsentPolicyBrowser } from './consentPolicyBrowser'
import { ConsentPolicyAppMountHandler } from './consentPolicyAppMountHandler'
import { ConsentPolicySdkHandlersProvider } from './consentPolicySdkHandlersProvider'

export { createConsentPolicyLogger } from './consentPolicyLogger'

export const site: ContainerModuleLoader = (bind) => {
	bind(ConsentPolicySymbol).to(ConsentPolicyBrowser)
	bind(WixCodeSdkHandlersProviderSym).to(ConsentPolicySdkHandlersProvider)
	bind(LifeCycle.AppWillMountHandler).to(ConsentPolicyAppMountHandler)
}

export const editor = site

export * from './types'
export * from './symbols'
