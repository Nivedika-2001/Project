import { withDependencies, named } from '@wix/thunderbolt-ioc'
import { FeatureExportsSymbol, IAppWillMountHandler } from '@wix/thunderbolt-symbols'
import type { IConsentPolicy } from './types'
import { name, ConsentPolicySymbol } from './symbols'
import { IFeatureExportsStore } from 'thunderbolt-feature-exports'

export const ConsentPolicyAppMountHandler = withDependencies<IAppWillMountHandler>(
	[ConsentPolicySymbol, named(FeatureExportsSymbol, name)],
	(consentPolicyAPI: IConsentPolicy, consentPolicyExports: IFeatureExportsStore<typeof name>) => {
		return {
			appWillMount() {
				consentPolicyExports.export({
					currentConsentPolicy: consentPolicyAPI.getCurrentConsentPolicy(),
				})
			},
		}
	}
)
