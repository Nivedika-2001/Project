export const name = 'cookiesManager' as const

export const CookiesManagerSymbol = Symbol('CookiesManager')
