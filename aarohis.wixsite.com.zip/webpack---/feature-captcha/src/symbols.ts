export const name = 'captcha' as const
