export const name = 'sliderGallery' as const
