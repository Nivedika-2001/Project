export const name = 'customCss' as const
export const CustomCssAPISymbol = Symbol('CustomCssAPISymbol')
