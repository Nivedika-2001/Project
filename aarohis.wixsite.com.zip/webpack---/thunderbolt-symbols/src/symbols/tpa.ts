export const TpaHandlerProviderSymbol = Symbol('TpaHandlerProvider')
export const TpaSrcQueryParamProviderSymbol = Symbol('TpaSrcQueryParamProvider')
export const TpaPopupSymbol = Symbol('TpaPopup')
