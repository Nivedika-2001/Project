export const CurrentRouteInfoSymbol = Symbol('CurrentRouteInfo')
export const SamePageUrlChangeListenerSymbol = Symbol('SamePageUrlChangeListener')
export const NavigationInfoSymbol = Symbol('NavigationInfo')
export const PagesMapSymbol = Symbol('PagesMap')
