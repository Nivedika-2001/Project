export const LinkClickHandlerSymbol = Symbol('LinkClickHandler')
export const SiteLinkClickHandlerSymbol = Symbol('SiteLinkClickHandlerSymbol')
export const NavigationClickHandlerSymbol = Symbol('NavigationClickHandlerSymbol')
