export const Fetch = Symbol('Fetch')
export const ContextWrappedFetchSym = Symbol('ContextWrappedFetch')
