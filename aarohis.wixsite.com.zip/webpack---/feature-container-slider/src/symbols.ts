export const name = 'containerSlider' as const
